
#include "pokemon.h"

int writefile( struct pokemon [], int, char []);

int readfile( struct pokemon [], int*, char []);
